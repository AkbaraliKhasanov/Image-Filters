package ali.akbarali.imagefilters.dependencyinjection

import org.koin.dsl.module
import org.koin.androidx.viewmodel.ext.android.viewModel

val viewModelModule = module {
    viewMod{

    }
}
package ali.akbarali.imagefilters.dependencyinjection

import ali.akbarali.imagefilters.repositories.EditImageRepository
import ali.akbarali.imagefilters.repositories.EditImageRepositoryImpl
import org.koin.dsl.module

val repositoryModule = module {
    factory<EditImageRepository> { EditImageRepositoryImpl(get()) }
}